clear all
img1 = imread('boat/img1.pgm');
img2 = imread('boat/img2.pgm');
im1 = single(img1);
im2 = single(img2);
[frames1, desc1]=vl_sift(im1);
[frames2, desc2]=vl_sift(im2);
[matches] = vl_ubcmatch(desc1, desc2);
%% only select 50 point matches for clearness%%%
pts1 = frames1(:,matches(1,1:50));
pts2 = frames2(:,matches(2,1:50));

%% first show the matches without RANSAC
figure; imshow([img1, img2]);
line([pts1(1,:);size(im1,2)+pts2(1,:)],[pts1(2,:);pts2(2,:)]);

%% get the RANSAC transformation
besth = ransac_affine(pts1, pts2, img1, img2);

%% use the transformation get new matched point
AA = [];    
[m,n]=size(pts1);
for i = 1:n   % form the AA of the whole dataset in the first figure
    temp = pts1(1:2,i)';
    temp1 = [temp 0 0 1 0;0 0 temp 0 1];
    AA = [AA; temp1];
end
bprim = AA * besth;

%% store all 'bprim' into 'match1t', from 1-column to 2-column dataset
match1t = [];
[mm,nn] = size(bprim);
mm= mm/2
for i = 1:mm
   match1t =[ match1t ;  bprim(2*i-1) bprim(2*i)];
end

%% plot the new matches after appling RANSAC
figure;
imshow([img1 img2]);
hold on;
match1t = match1t';
line([pts1(1,:);size(im1,2)+match1t(1,:)],[pts1(2,:);match1t(2,:)]);
title('Image 1 and 2 with the original points and their transformed counterparts in image 2');




